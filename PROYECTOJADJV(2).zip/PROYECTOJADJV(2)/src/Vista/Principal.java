
package Vista;

public class Principal {

    public static void main(String[] args) {
        Vista menu = new Vista();
        menu.IniciarSesion();
        
        //contraseña 1234
    }
    
    
}
